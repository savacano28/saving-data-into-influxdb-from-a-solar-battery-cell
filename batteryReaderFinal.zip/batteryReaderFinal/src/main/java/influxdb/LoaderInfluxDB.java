package influxdb;

import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.InfluxDBIOException;
import org.influxdb.dto.*;
import org.omg.CORBA.MARSHAL;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

public class LoaderInfluxDB {

    private InfluxDB connection;

    public LoaderInfluxDB(String databaseURL, String userName, String password)  {
        connection (databaseURL,userName,password);
    }

    public void connection(String databaseURL, String userName, String password){

        connection = InfluxDBFactory.connect(databaseURL, userName, password);
        pingServer(connection);
    }

    private boolean pingServer(InfluxDB influxDB) {
        try {
            // Ping and check for version string
            Pong response = influxDB.ping();
            if (response.getVersion().equalsIgnoreCase("unknown")) {
                System.out.println("Error pinging server.");
                return false;
            } else {
                //log.info("Database version: {}", response.getVersion());
                System.out.println("Database version: "+ response.getVersion());
                return true;
            }
        } catch (InfluxDBIOException idbo) {
            System.out.println("Exception while pinging database: "+ idbo);
            return false;
        }
    }


    public void loadValuesInfluxDB(String dataBaseName,Map<String, Map<String, String>> data)  {

        List<String> dataK = new ArrayList<String>(data.keySet());

        if (connection.databaseExists(dataBaseName) && data.size()>0){
            System.out.println("------------------------------------------------data to load "+ data.size());
            BatchPoints batchPoints = BatchPoints
                    .database(dataBaseName)
                    .tag("async", "true")
                    .build();

            for (int i=0; i<dataK.size();i++) {
                final Map<String,Object> dataO=new HashMap<>();
                dataO.putAll(data.get(dataK.get(i)));
                Point point = Point.measurement(dataK.get(i).substring(0,dataK.get(i).indexOf("-")))
                        .time(System.currentTimeMillis(), TimeUnit.NANOSECONDS)
                        .tag("uniq", String.valueOf(i))
                        .fields(dataO)
                        .build();
                data.remove(dataK.get(i));
                batchPoints.point(point);
            }
            connection.write(batchPoints);
        }
        //Test
        /*Query query = new Query("SELECT * FROM VI", "influxdb");
        QueryResult result = connection.query(query);*/
        connection.close();
    }
}
