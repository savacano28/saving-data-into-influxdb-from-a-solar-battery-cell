package batteryreaderpage;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReaderValuesPage {

    private List <String> valuesToInflixDB;
    private List <String> valuesPage;
    private String [] stringvalues;

    public ReaderValuesPage(){
        valuesPage=new ArrayList<>();
        valuesToInflixDB=new ArrayList<>();
    }

    public Map<String,Object> getValuesToInfluxBD (String file, List <String> previewValues, Object delta) throws IOException {

        valuesToInflixDB=applyFilterstoValues( previewValues, getValuesfromPage(file), (Map<String, String>) delta);
      //  valuesToInflixDB=getValuesfromPage(file);

        Map<String,Object> map = new LinkedHashMap<>();  // ordered

        List<String> keys=new ArrayList<>(((Map<String, String>) delta).keySet());

        if (valuesToInflixDB!=null){
        for (int i=0; i<valuesToInflixDB.size(); i++) {
            map.put(keys.get(i),valuesToInflixDB.get(i) );
        }
        }

        return map;
    }

    public List <String> getValuesfromPage(String file) throws IOException {
        Document doc = null;
        doc = Jsoup.parse(new File(file), "utf-8");
        valuesPage=getValueInner(doc.body().toString());
        return valuesPage;
    }

     public List <String> applyFilterstoValues( List <String> previewValues , List <String> newValues, Map<String, String> deltas){

        List <String> listS=new ArrayList<>();
        if (deltas.containsKey("stringvalues")){
            stringvalues=deltas.get("stringvalues").split(",");
            listS = (List) Arrays.asList(stringvalues);
           // deltas.remove("stringvalues");
        }

        List<String> deltaV = new ArrayList<>(deltas.values());
        List<String> deltaK = new ArrayList<>(deltas.keySet());
        List<String> previewV = new ArrayList<>(previewValues);
        //deltas.put("stringvalues",stringvalues.toString());

        for (int i=0;i<newValues.size();i++) {
            if(!listS.contains(deltaK.get(i))){
               if(Math.abs(Double.parseDouble((String) previewV.get(i)) -  Double.parseDouble(newValues.get(i))) >= Double.parseDouble(deltaV.get(i))) {
                   return newValues;
               }
            }
        }

        return null;
    }

    public List<String> getValueInner(String values ) {

        Pattern p = Pattern.compile("(readonly value=\")(.*?)(\">)");
        Matcher m = p.matcher(values);
        List<String> matches = new ArrayList<String>();
        while (m.find()) {
            matches.add(m.group(2));
        }

        return matches;
    }

}
