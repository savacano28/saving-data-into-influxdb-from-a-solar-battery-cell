package batteryreaderpage;

import influxdb.LoaderInfluxDB;
import org.influxdb.dto.Point;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

public class BatteryReaderPageCtrl {

    private ReaderValuesPage readerValuesPage;
    private LoaderInfluxDB loaderInfluxDB;
    private Map<String, List<String>> pagesToInfluxdb;
    private InputStream inputStream;
    private String [] pages;
    private String pathServeur;
    private String influxdburl;
    final private String INNER_FILE= "_inner.htm";
    final private String T_FILE= ".config.properties";

    public BatteryReaderPageCtrl() throws IOException {
        readerValuesPage = new ReaderValuesPage();
        loaderInfluxDB = new LoaderInfluxDB();
        pagesToInfluxdb =new HashMap<String, List<String>>();
        getProperties();
    }

    public void getProperties() throws IOException {
        Properties prop = new Properties();
        String propFileName = "global.config.properties";

        inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);

        if (inputStream != null) {
            prop.load(inputStream);
        } else {
            throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
        }

       pages = prop.getProperty("pages").split(",");
       pathServeur=prop.getProperty("serveur");
       influxdburl=prop.getProperty("influxdb.url");
  }

    public void reader() throws IOException{

        for(String s : pages) {
            pagesToInfluxdb.put(s,readerValuesPage.getValuesToInfluxBD(pathServeur+s.concat(INNER_FILE), s.toLowerCase().replace("_","").concat(T_FILE)));
         }

         loaderInfluxDB.connection("localhost:8086","admin","admin");
//        loaderInfluxDB.loadValuesInfluxDB(pagesToInfluxdb);
    }

}
