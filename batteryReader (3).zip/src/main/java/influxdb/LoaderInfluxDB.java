package influxdb;

import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.InfluxDBIOException;
import org.influxdb.dto.BatchPoints;
import org.influxdb.dto.Point;
import org.influxdb.dto.Pong;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class LoaderInfluxDB {

    private static final Logger log = LoggerFactory.getLogger(LoaderInfluxDB.class);
    private InfluxDB influxDB;

    public void loadValuesInfluxDB(Map<String,List<String>> values){
      //  makePoint(values.getValue());

    }

    public void connection(String databaseURL, String userName, String password){

        InfluxDB connection = connectDatabase();
        pingServer(connection);
    }

    private InfluxDB connectDatabase() {

        // Connect to database assumed on localhost with default credentials.
        return  InfluxDBFactory.connect("http://localhost:8086", "admin", "admin");

    }

    private boolean pingServer(InfluxDB influxDB) {
        try {
            // Ping and check for version string
            Pong response = influxDB.ping();
            if (response.getVersion().equalsIgnoreCase("unknown")) {
                log.error("Error pinging server.");
                return false;
            } else {
                log.info("Database version: {}", response.getVersion());
                System.out.println("Database version: {}"+ response.getVersion());
                return true;
            }
        } catch (InfluxDBIOException idbo) {
            log.error("Exception while pinging database: ", idbo);
            return false;
        }
    }


   /* public void connection(String databaseURL, String userName, String password){

        influxDB = InfluxDBFactory.connect(databaseURL, userName, password);
        Pong response = influxDB.ping();
        if (response.getVersion().equalsIgnoreCase("unknown")) {
            log.error("Error pinging server.");
            return;
        }
        influxDB.setLogLevel(InfluxDB.LogLevel.BASIC);
    }*/

    public Point makePoint(List<String> values){

        Point point=null;

        return point;
    }

    public boolean savePointsInfluxDB(Map<String,Point> pointMap){
        BatchPoints batchPoints = BatchPoints
                .database("dbName")
                .retentionPolicy("defaultPolicy")
                .build();

        Point point1 = Point.measurement("memory")
                .time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
                .addField("name", "server1")
                .addField("free", 4743656L)
                .addField("used", 1015096L)
                .addField("buffer", 1010467L)
                .build();

        Point point2 = Point.measurement("memory")
                .time(System.currentTimeMillis() - 100, TimeUnit.MILLISECONDS)
                .addField("name", "server1")
                .addField("free", 4743696L)
                .addField("used", 1016096L)
                .addField("buffer", 1008467L)
                .build();

        batchPoints.point(point1);
        batchPoints.point(point2);
        influxDB.write(batchPoints);

        return true;

    }
}
