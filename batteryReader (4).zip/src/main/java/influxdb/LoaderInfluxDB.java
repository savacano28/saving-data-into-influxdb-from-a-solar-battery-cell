package influxdb;

import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.InfluxDBIOException;
import org.influxdb.dto.BatchPoints;
import org.influxdb.dto.Point;
import org.influxdb.dto.Pong;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class LoaderInfluxDB {

    private static final Logger log = LoggerFactory.getLogger(LoaderInfluxDB.class);
    private InfluxDB connection;

    public LoaderInfluxDB(String databaseURL, String userName, String password)  {
        connection (databaseURL,userName,password);
    }

    public void connection(String databaseURL, String userName, String password){
        connection = InfluxDBFactory.connect(databaseURL, userName, password);
        pingServer(connection);
    }

    private boolean pingServer(InfluxDB influxDB) {
        try {
            // Ping and check for version string
            Pong response = influxDB.ping();
            if (response.getVersion().equalsIgnoreCase("unknown")) {
                log.error("Error pinging server.");
                return false;
            } else {
                log.info("Database version: {}", response.getVersion());
                System.out.println("Database version: "+ response.getVersion());
                return true;
            }
        } catch (InfluxDBIOException idbo) {
            log.error("Exception while pinging database: ", idbo);
            return false;
        }
    }


    public void loadValuesInfluxDB(Collection<List<String>> data){
      //  makePoint(values.getValue());
        if (connection.databaseExists("influxdb")){
        System.out.println("------------------------------------------------Loaded data "+ data.size());
        }

    }

    public Point makePoint(List<String> values){
        Point point=null;
        return point;
    }

    public boolean savePointsInfluxDB(Map<String,Point> pointMap){
        BatchPoints batchPoints = BatchPoints
                .database("dbName")
                .retentionPolicy("defaultPolicy")
                .build();

        Point point1 = Point.measurement("memory")
                .time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
                .addField("name", "server1")
                .addField("free", 4743656L)
                .addField("used", 1015096L)
                .addField("buffer", 1010467L)
                .build();

        Point point2 = Point.measurement("memory")
                .time(System.currentTimeMillis() - 100, TimeUnit.MILLISECONDS)
                .addField("name", "server1")
                .addField("free", 4743696L)
                .addField("used", 1016096L)
                .addField("buffer", 1008467L)
                .build();

        batchPoints.point(point1);
        batchPoints.point(point2);
        connection.write(batchPoints);

        return true;
    }
}
