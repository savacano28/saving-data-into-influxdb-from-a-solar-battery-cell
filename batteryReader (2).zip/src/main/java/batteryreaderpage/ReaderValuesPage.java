package batteryreaderpage;

import batteryreaderpage.BatteryReaderPageCtrl;
import org.influxdb.dto.Point;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReaderValuesPage {

    private List <String> valuesToInflixDB;
    private List <String> valuesPage;
    private Map<String, String> threshold;
    private InputStream inputStream;
    private String [] stringvalues;

    public ReaderValuesPage(){
        valuesPage=new ArrayList<String>();
        valuesToInflixDB=new ArrayList<String>();
        threshold=new LinkedHashMap<String, String >();
    }

    public List<String> getValuesToInfluxBD (String file, String thresholdFile) throws IOException {
       valuesToInflixDB=applyFilterstoValues(getValuesfromPage(file) ,getThresholdsFromProperties(thresholdFile));
      //  valuesToInflixDB=getValuesfromPage(file);
        return valuesToInflixDB;
    }

    public List <String> getValuesfromPage(String file) throws IOException {
        Document doc = null;
        doc = Jsoup.parse(new File(file), "utf-8");
        valuesPage=getValueInner(doc.body().toString());
        return valuesPage;
    }

    public Map<String, String> getThresholdsFromProperties(String thresholdFile) throws IOException {
        OrderedProperties prop = new OrderedProperties();
        String propFileName = thresholdFile;
        threshold.clear();
        inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);

        if (inputStream != null) {
            prop.load(inputStream);
        } else {
            throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
        }

        stringvalues = prop.getProperty("stringvalues").split(",");

        Enumeration <?> e = prop.propertyNames();
        while (e.hasMoreElements()) {
            String key = (String) e.nextElement();
            System.out.println(key + " -- " + prop.getProperty(key));
            threshold.put(key, prop.getProperty(key));
        }

        return threshold;
    }

    public List<String> applyFilterstoValues( List <String> values , Map<String, String> threshold){
        int i=0;
        for (String value : values) {
//            conditional de string et dates si.. key es ???

           if(Double.parseDouble(value) <  Double.parseDouble(threshold.get(i))) {
               value = threshold.get(i);

           }
           i++;
        }

        /*
        * che sys
        * check.invertertype
        * check.operationmodesmaa=0
        * check.operationmodesmab=0
        * vi
        * vi.charging=0
        * stats
        * st.date=0
        * st.time=0
        * addi
        * additional.batterymode=0
        * additional.h2.sw-version=0
        * additional.hw-version=0
        * additional.sw-version=0
        * bv.neg.electrolyteely-tankcover=0
        * bv.pos.electrolyteely-tankcover=0
        *
*/
        return values;
    }

    public List<String> getValueInner(String values ) {

        Pattern p = Pattern.compile("(readonly value=\")(.*?)(\">)");
        Matcher m = p.matcher(values);
        List<String> matches = new ArrayList<String>();
        while (m.find()) {
            matches.add(m.group(2));
        }

        return matches;
    }

}
