import batteryreaderpage.BatteryReaderPageCtrl;

import java.io.IOException;

public class App {
    public static void main(String[] args) throws IOException {

        BatteryReaderPageCtrl batteryReaderPageCtrl=new BatteryReaderPageCtrl();
        batteryReaderPageCtrl.reader();

    }

}

/**
 * Example program to list links from a URL.
 */

/*public class App {
public static void main(String[] args) throws IOException {
    // Validate.isTrue(args.length == 1, "usage: supply url to fetch");
       /* System.setProperty("http.proxyHost", "issrvpxw1-std");
        System.setProperty("http.proxyPort", "8082");
        Document doc = Jsoup.connect("http://www.ifpenergiesnouvelles.fr/").get();

    Document doc = Jsoup.parse(new File("///C:/Users/casanovs/Documents/3603_captureDataXMLUniteRedox/docs/Espion-light.html"), "utf-8");
    System.out.println("Obtained Body: " + doc.body());
}

    private static void print(String msg, Object... args) {
        System.out.println(String.format(msg, args));
    }

    private static String trim(String s, int width) {
        if (s.length() > width)
            return s.substring(0, width-1) + ".";
        else
            return s;
    }
}*/

/*public class App {
    private static final Logger log = LoggerFactory.getLogger(App.class);

    public static void main(String[] args) {
        String url = "http://www.ifpenergiesnouvelles.fr/";
        log.info("Connecting to {}", url);

        // Go to url
        try {
            Document doc = Jsoup.connect(url).get();
            log.info(doc.title());
            Elements newsHeadlines = doc.select("#mp-itn b a");
            for (Element headline : newsHeadlines) {
                log.info("{} => {}", headline.attr("title"), headline.absUrl("href"));
            }
            // Test if title is : "Historian Web Services"
            String textFound = doc.select("h1").text();
            log.debug("Text found={}", textFound);
            if (textFound.contains("Historian Web Services")) {
                log.info("Test passes!");
            } else {
                log.error("Test fails!");
            }
        } catch (Exception e) {
            log.error("Error: {}", e.getMessage(), e);
        }
        log.info("Test complete");
    }
}*/

/*public class App{
    public static void main(String[] args) throws IOException {
//        Validate.isTrue(args.length == 1, "usage: supply url to fetch");
        System.setProperty("http.proxyHost", "issrvpxw1-pri");
        System.setProperty("http.proxyPort", "8082");
        String url = "http://www.ifpenergiesnouvelles.fr/";
        print("Fetching %s...", url);

        Document doc = Jsoup.connect(url).get();
        Elements links = doc.select("a[href]");
        Elements media = doc.select("[src]");
        Elements imports = doc.select("link[href]");

        print("\nMedia: (%d)", media.size());
        for (Element src : media) {
            if (src.tagName().equals("img"))
                print(" * %s: <%s> %sx%s (%s)",
                        src.tagName(), src.attr("abs:src"), src.attr("width"), src.attr("height"),
                        trim(src.attr("alt"), 20));
            else
                print(" * %s: <%s>", src.tagName(), src.attr("abs:src"));
        }

        print("\nImports: (%d)", imports.size());
        for (Element link : imports) {
            print(" * %s <%s> (%s)", link.tagName(),link.attr("abs:href"), link.attr("rel"));
        }

        print("\nLinks: (%d)", links.size());
        for (Element link : links) {
            print(" * a: <%s>  (%s)", link.attr("abs:href"), trim(link.text(), 35));
        }
    }

    private static void print(String msg, Object... args) {
        System.out.println(String.format(msg, args));
    }

    private static String trim(String s, int width) {
        if (s.length() > width)
            return s.substring(0, width-1) + ".";
        else
            return s;
    }

}*/
