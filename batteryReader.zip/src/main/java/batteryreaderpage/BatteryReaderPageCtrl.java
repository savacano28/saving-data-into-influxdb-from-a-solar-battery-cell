package batteryreaderpage;

import influxdb.LoaderInfluxDB;
import org.influxdb.dto.Point;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BatteryReaderPageCtrl {

    private ReaderValuesPage readerValuesPage;
    private LoaderInfluxDB loaderInfluxDB;
    private Map<String, List<String>> pagesToInfluxdb;

    public BatteryReaderPageCtrl()  {
        readerValuesPage = new ReaderValuesPage();
        loaderInfluxDB = new LoaderInfluxDB();
        pagesToInfluxdb =new HashMap<String, List<String>>();
    }

    public void reader() throws IOException{
        for(Page page : Page.values()) {
            pagesToInfluxdb.put(page.getNamePage(),readerValuesPage.getValuesToInfluxBD(page.getPathPage(), null));
        }

        loaderInfluxDB.loadValuesInfluxDB(pagesToInfluxdb);
    }

}
