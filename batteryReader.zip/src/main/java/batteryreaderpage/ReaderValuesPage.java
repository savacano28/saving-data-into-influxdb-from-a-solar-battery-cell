package batteryreaderpage;

import batteryreaderpage.BatteryReaderPageCtrl;
import org.influxdb.dto.Point;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReaderValuesPage {

    private List <String> valuesToInflixDB;
    private List <String> valuesPage;

    public ReaderValuesPage(){
        valuesPage=new ArrayList<String>();
        valuesToInflixDB=new ArrayList<String>();
    }

    public List<String> getValuesToInfluxBD (String file, List <String> threshold) throws IOException {
        valuesToInflixDB=getValuesfromPage(file);
        return valuesToInflixDB;
    }

    public List <String> getValuesfromPage(String file) throws IOException {
        Document doc = null;
        doc = Jsoup.parse(new File(file), "utf-8");
        valuesPage=getValueInner(doc.body().toString());
        return valuesPage;
    }

    public List<String> applyFilterstoValues( List <String> values , List <String> threshold){
        int i=0;
        for (String value : values) {
           if(Integer.parseInt(value) <  Integer.parseInt(threshold.get(i))) {
               value = threshold.get(i);
           }
           i++;
        }

        return null;
    }

    public List<String> getValueInner(String values ) {

        Pattern p = Pattern.compile("(readonly value=\")(.*?)(\">)");
        Matcher m = p.matcher(values);
        List<String> matches = new ArrayList<String>();
        while (m.find()) {
            matches.add(m.group(2));
        }

        return matches;
    }

}
