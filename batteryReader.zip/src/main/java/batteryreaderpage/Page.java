package batteryreaderpage;

public enum Page {
/*    VI_PAGE("VI","/VI_inner"),
    BATTERY_VALUES_PAGE("BATTERY_VALUES","/VI_inner"),
    ADDITIONAL_PAGE("ADDITIONAL","/VI_inner"),
    CHECK_SYSTEM_PAGE("CHECK_SYSTEM","/VI_inner"),
    SMAA_PAGE("SMAA","/VI_inner"),
    SMAB_PAGE("SMAB","/VI_inner"),
    STATISTIC_PAGE("STATISTIC","/VI_inner");*/

    VI_PAGE("VI","///C:/Users/casanovs/Documents/3603_captureDataXMLUniteRedox/docs/pages/vi_inner.htm"),
    BATTERY_VALUES_PAGE("BATTERY_VALUES","///C:/Users/casanovs/Documents/3603_captureDataXMLUniteRedox/docs/pages/batteryvalues_inner.htm"),
    ADDITIONAL_PAGE("ADDITIONAL","///C:/Users/casanovs/Documents/3603_captureDataXMLUniteRedox/docs/pages/additional_inner.htm"),
    CHECK_SYSTEM_PAGE("CHECK_SYSTEM","///C:/Users/casanovs/Documents/3603_captureDataXMLUniteRedox/docs/pages/checksystem_inner.htm"),
    SMAA_PAGE("SMAA","///C:/Users/casanovs/Documents/3603_captureDataXMLUniteRedox/docs/pages/smaa_inner.htm"),
    SMAB_PAGE("SMAB","///C:/Users/casanovs/Documents/3603_captureDataXMLUniteRedox/docs/pages/smab_inner.htm"),
    STATISTIC_PAGE("STATISTIC","///C:/Users/casanovs/Documents/3603_captureDataXMLUniteRedox/docs/pages/statistic_inner.htm");

    private String pathPage;
    private String namePage;

    Page(String name, String path) {
       namePage=name;
       pathPage=path;
    }

    public String getPathPage() {
        return pathPage;
    }

    public String getNamePage() {
        return namePage;
    }

//  readerValuesPage.readerValuesPage("///C:/Users/casanovs/Documents/3603_captureDataXMLUniteRedox/docs/pages",null);



}
