package influxdb;

import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.InfluxDBIOException;
import org.influxdb.dto.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class LoaderInfluxDB {

    private static final Logger log = LoggerFactory.getLogger(LoaderInfluxDB.class);
    private InfluxDB connection;

    public LoaderInfluxDB(String databaseURL, String userName, String password)  {
        connection (databaseURL,userName,password);
    }

    public void connection(String databaseURL, String userName, String password){
        connection = InfluxDBFactory.connect(databaseURL, userName, password);
        pingServer(connection);
    }

    private boolean pingServer(InfluxDB influxDB) {
        try {
            // Ping and check for version string
            Pong response = influxDB.ping();
            if (response.getVersion().equalsIgnoreCase("unknown")) {
                log.error("Error pinging server.");
                return false;
            } else {
                log.info("Database version: {}", response.getVersion());
                System.out.println("Database version: "+ response.getVersion());
                return true;
            }
        } catch (InfluxDBIOException idbo) {
            log.error("Exception while pinging database: ", idbo);
            return false;
        }
    }


    public void loadValuesInfluxDB(Map<String,Map<String,Object>> data)  {

        List<Map<String,Object>> dataV = new ArrayList<Map<String,Object>>(data.values());
        List<String> dataK = new ArrayList<String>(data.keySet());
        System.out.println("------------------------------------------------loading");

      //  makePoint(values.getValue());
        if (connection.databaseExists("influxdb") && data.size()>0){
        System.out.println("------------------------------------------------Loaded data "+ data.size());
          /*  BatchPoints batchPoints = BatchPoints
                    .database("influxdb")
                    .retentionPolicy("defaultPolicy")
                    .build();*/

         /*   for (int i=0; i<dataK.size();i++) {
                Point point = Point.measurement(dataK.get(i).substring(0,dataK.get(i).indexOf("-")))
                        .time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
                        .fields(dataV.get(i))
                        .build();

                batchPoints.point(point);
            }*/
            BatchPoints batchPoints = BatchPoints.database("influxdb").tag("async", "true").build();

            Point point = Point
                    .measurement("cpu")
                    .tag("atag", "test")
                    .addField("idle", 90L)
                    .addField("usertime", 9L)
                    .addField("system", 1L)
                    .build();

            batchPoints.point(point);
            connection.write(batchPoints);

        }

        Query query = new Query("SELECT * FROM cpu ", "influxdb");
        QueryResult result = connection.query(query);
        connection.close();
    }

    public Point makePoint(List<String> values){
        Point point=null;
        return point;
    }

    public boolean savePointsInfluxDB(Map<String,Point> pointMap){
        BatchPoints batchPoints = BatchPoints
                .database("influxdb")
                .retentionPolicy("defaultPolicy")
                .build();

        Point point1 = Point.measurement("memory")
                .time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
                .addField("name", "server1")


                .addField("free", 4743656L)
                .addField("used", 1015096L)
                .addField("buffer", 1010467L)
                .build();

        Point point2 = Point.measurement("memory")
                .time(System.currentTimeMillis() - 100, TimeUnit.MILLISECONDS)
                .addField("name", "server1")
                .addField("free", 4743696L)
                .addField("used", 1016096L)
                .addField("buffer", 1008467L)
                .build();

        batchPoints.point(point1);
        batchPoints.point(point2);
        connection.write(batchPoints);

        return true;
    }
}
