package batteryreaderpage;

import batteryreaderpage.BatteryReaderPageCtrl;
import org.influxdb.dto.Point;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReaderValuesPage {

    private List <String> valuesToInflixDB;
    private List <String> valuesPage;
    private Map<String, String> threshold;
    private InputStream inputStream;
    private String [] stringvalues;

    public ReaderValuesPage(){
        valuesPage=new ArrayList<String>();
        valuesToInflixDB=new ArrayList<String>();
    }

    public List<String> getValuesToInfluxBD (String file, Object delta) throws IOException {
        valuesToInflixDB=applyFilterstoValues(valuesToInflixDB, getValuesfromPage(file), (Map<String, String>) delta);
     //   valuesToInflixDB=getValuesfromPage(file);

        return valuesToInflixDB;
    }

    public List <String> getValuesfromPage(String file) throws IOException {
        Document doc = null;
        doc = Jsoup.parse(new File(file), "utf-8");
        valuesPage=getValueInner(doc.body().toString());
        return valuesPage;
    }

     public List <String> applyFilterstoValues( List <String> previewValues , List <String> newValues, Map<String, String> deltas){
        stringvalues=deltas.get("stringvalues").split(",");
        List <String> listS = (List) Arrays.asList(stringvalues);
        deltas.remove("stringvalues");

        List<String> deltaV = new ArrayList<String>(deltas.values());
        List<String> deltaK = new ArrayList<String>(deltas.keySet());

        for (int i=0;i<newValues.size();i++) {
//            conditional de string et dates si.. par key ???
            if(!listS.contains(deltaK.get(i))){
               if(Math.abs(Double.parseDouble(previewValues.get(i)) -  Double.parseDouble(newValues.get(i))) >= Double.parseDouble(deltaV.get(i))) {
                   return newValues;
               }
            }
        }

        return null;
    }

    public List<String> getValueInner(String values ) {

        Pattern p = Pattern.compile("(readonly value=\")(.*?)(\">)");
        Matcher m = p.matcher(values);
        List<String> matches = new ArrayList<String>();
        while (m.find()) {
            matches.add(m.group(2));
        }

        return matches;
    }

}
